package der.utils.constants;

/**
 * Created by bukhoriaqid on 11/27/16. integer constants
 */

public class I
{
    public static final int HTTP_NO_CONTENT       = 204;
    public static final int CAMERA_REQUEST_CODE   = 999;
    public static final int LOCATION_REQUEST_CODE = 998;
    public static final int SPLASH_DISPLAY_LENGTH = 500;
}
