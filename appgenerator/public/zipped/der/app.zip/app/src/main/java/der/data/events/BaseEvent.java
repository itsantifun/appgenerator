package der.data.events;

/**
 * Created by bukhoriaqid on 11/12/16. abstract base parent for all event classes
 */

public abstract class BaseEvent
{}
