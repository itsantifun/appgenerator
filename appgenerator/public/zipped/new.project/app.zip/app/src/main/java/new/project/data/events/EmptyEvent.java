package new.project.data.events;

/**
 * Created by bukhoriaqid on 11/11/16.
 */

public class EmptyEvent extends BaseEvent
{}
