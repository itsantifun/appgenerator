package deka.crepes.utils.constants;

/**
 * Created by bukhoriaqid on 11/12/16. class to contain key values
 */

public class K
{

}
