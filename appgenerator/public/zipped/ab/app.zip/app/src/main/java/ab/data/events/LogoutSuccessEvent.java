package ab.data.events;

/**
 * Created by bukhoriaqid on 11/12/16.
 */

public class LogoutSuccessEvent extends BaseEvent
{}
