package yea.viewmodels;

import android.view.View;

/**
 * Created by bukhoriaqid on 11/27/16.
 */

public class UserListViewModel extends BaseViewModel
{
    public int listVisibility = View.VISIBLE;
}
