package ter.viewmodels;

import android.databinding.BaseObservable;

/**
 * Created by bukhoriaqid on 11/10/16.
 */

public abstract class BaseViewModel extends BaseObservable
{}
